/*********************************************************************************************************
      INIZIO PARTE DEFINITA PER PROGETTO
			AUTORE: Alex Carluccio
			UNIVERITA': Politecnico di Torino
			ANNO: 2021-2022
*********************************************************************************************************/
#include <stdio.h>
#include <stdbool.h> 
#include "LPC17xx.H"                   
#include "../GLCD/GLCD.h"
#include "../game/gamefield.h"
#include "../game/ball.h"

void youLose(void);
void scoreAndRecordPrint(void);



/*********************************************************************************************************
      END FILE
*********************************************************************************************************/

