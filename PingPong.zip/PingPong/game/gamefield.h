/*********************************************************************************************************
      INIZIO PARTE DEFINITA PER PROGETTO
			AUTORE: Alex Carluccio
			UNIVERITA': Politecnico di Torino
			ANNO: 2021-2022
*********************************************************************************************************/
#include "LPC17xx.h"
#include <stdbool.h> 

void LCD_GameSetup(void);  
void PaddleMovment(uint16_t Xnewpox);
void PaddleMovmentDelete(uint16_t Xnewpos);
int paddlePosition(void);
int paddleLenght(void);
int paddleAltitude(void);
int fieldXdestralimit(void);
int fieldXsinistralimit(void);
int fieldYbassolimit(void);
int fieldYaltolimit(void);
int paddlePosition(void);
int paddleLenght(void);

/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
