/*********************************************************************************************************
      INIZIO PARTE DEFINITA PER PROGETTO
			AUTORE: Alex Carluccio
			UNIVERITA': Politecnico di Torino
			ANNO: 2021-2022
*********************************************************************************************************/
#include <stdio.h>
#include <stdbool.h> 
#include "LPC17xx.H"                   
#include "../GLCD/GLCD.h"
#include "../game/gamefield.h"


void ballMovment(int incrementX, int incrementY);
void checkBallOut(void);
void setPosition(int x, int y);
void resetVelocity(void);
void bounceManagementPaddle(void);
void bounceManagementLeft(void);
void bounceManagementTop(void);
void bounceManagementRight(void);
int ballXCurrentPosition(void);
int ballYCurrentPosition(void);
void checkPosition(void);
void resetGame(void);
void startGame(void);
void resumeGame(void);
void pauseGame(void);
void gameSpeed(void);


/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
