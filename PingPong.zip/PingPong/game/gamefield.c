/*********************************************************************************************************
      INIZIO PARTE DEFINITA PER PROGETTO
			AUTORE: Alex Carluccio
			UNIVERITA': Politecnico di Torino
			ANNO: 2021-2022
*********************************************************************************************************/
#include <stdio.h>
#include <stdbool.h> 
#include "LPC17xx.H"                   
#include "../GLCD/GLCD.h"

uint16_t Xsinistra=4;
uint16_t Xdestra=235;

uint16_t Yalto=4;
uint16_t Ybasso=277;

uint16_t Xpos;
uint16_t Ypos=277;
uint16_t paddleLen=62;

/*********************************************************************************************************
      DISPLAY PART
*********************************************************************************************************/


void LCD_GameSetup(void){  //Funzione per disegnare i bordi rossi del campo da gioco
   LCD_Clear(Black);
	
	 //Il display va su x da 0 a 239 e y da 0 a 319   dunque 240x320
	
	 //Set linea 5px alta//
	 LCD_DrawLine(0,0,239,0,Red);
	 LCD_DrawLine(0,1,239,1,Red);
	 LCD_DrawLine(0,2,239,2,Red);
	 LCD_DrawLine(0,3,239,3,Red);
	 LCD_DrawLine(0,4,239,4,Red);
	
	 //Set linea 5px sinsitra//
	 LCD_DrawLine(0,0,0,277,Red);
	 LCD_DrawLine(1,0,1,277,Red);
	 LCD_DrawLine(2,0,2,277,Red);
	 LCD_DrawLine(3,0,3,277,Red);
	 LCD_DrawLine(4,0,4,277,Red);
	 
	 //Set linea 5px destra//
	 LCD_DrawLine(239,0,239,277,Red);
	 LCD_DrawLine(238,0,238,277,Red);
	 LCD_DrawLine(237,0,237,277,Red);
	 LCD_DrawLine(236,0,236,277,Red);
	 LCD_DrawLine(235,0,235,277,Red);
	 
}


void PaddleMovment(uint16_t Xnewpos){ //Funzione per graficare il paddle, utilizza come riferimento le coordinate del punto situato nell'angolo in alto a sinistra

	 //Xnewpos si riferisce all'angolo in alto a sinistra del paddle
	 LCD_DrawLine(Xnewpos,277,(Xnewpos+61),277,Green);
	 LCD_DrawLine(Xnewpos,278,(Xnewpos+61),278,Green);
	 LCD_DrawLine(Xnewpos,279,(Xnewpos+61),279,Green);
	 LCD_DrawLine(Xnewpos,280,(Xnewpos+61),280,Green);
	 LCD_DrawLine(Xnewpos,281,(Xnewpos+61),281,Green);
	 LCD_DrawLine(Xnewpos,282,(Xnewpos+61),282,Green);
	 LCD_DrawLine(Xnewpos,283,(Xnewpos+61),283,Green);
	 LCD_DrawLine(Xnewpos,284,(Xnewpos+61),284,Green);
	 LCD_DrawLine(Xnewpos,285,(Xnewpos+61),285,Green);
   LCD_DrawLine(Xnewpos,286,(Xnewpos+61),286,Green);	
 	 Xpos=Xnewpos;
	 
}	

void PaddleMovmentDelete(uint16_t Xnewpos){ //Funzione per cancellare il vecchio paddle

	 //Xnewpos si riferisce all'angolo in alto a sinistra del paddle
	 LCD_DrawLine(Xnewpos,277,(Xnewpos+61),277,Black);
	 LCD_DrawLine(Xnewpos,278,(Xnewpos+61),278,Black);
	 LCD_DrawLine(Xnewpos,279,(Xnewpos+61),279,Black);
	 LCD_DrawLine(Xnewpos,280,(Xnewpos+61),280,Black);
	 LCD_DrawLine(Xnewpos,281,(Xnewpos+61),281,Black);
	 LCD_DrawLine(Xnewpos,282,(Xnewpos+61),282,Black);
	 LCD_DrawLine(Xnewpos,283,(Xnewpos+61),283,Black);
	 LCD_DrawLine(Xnewpos,284,(Xnewpos+61),284,Black);
	 LCD_DrawLine(Xnewpos,285,(Xnewpos+61),285,Black);
   LCD_DrawLine(Xnewpos,286,(Xnewpos+61),286,Black);	
}	





int paddlePosition(void){ //Funzione per avere la posizione del paddle corrente sull'asse X
  return Xpos;
}

int paddleAltitude(void){ //Funzione per avere la posizione del paddle corrente sull'asse Y
  return Ypos;
}
	
int paddleLenght(void){   //Funzione per avere la lunghezza del paddle
  return paddleLen;
}

/*********************************************************************************************************
      LIMIT FIELD PART
*********************************************************************************************************/

int fieldXdestralimit(void){   //Funzione per avere il limite del campo da gioco come valore di X destro
  return Xdestra;
}
int fieldXsinistralimit(void){ //Funzione per avere il limite del campo da gioco come valore di X sinistro
  return Xsinistra;
}
int fieldYbassolimit(void){    //Funzione per avere il limite del campo da gioco come valore di Y basso
  return Ybasso;
}
int fieldYaltolimit(void){     //Funzione per avere il limite del campo da gioco come valore di Y alto
  return Yalto;
}


/*********************************************************************************************************
      END FILE
*********************************************************************************************************/
