/*********************************************************************************************************
      INIZIO PARTE DEFINITA PER PROGETTO
			AUTORE: Alex Carluccio
			UNIVERITA': Politecnico di Torino
			ANNO: 2021-2022
*********************************************************************************************************/
#include <stdio.h>
#include <string.h>
#include <stdbool.h> 
#include "LPC17xx.H"                   
#include "../GLCD/GLCD.h"
#include "../game/gamefield.h"
#include "../game/ball.h"
int score=0;
int record=100;
char scoretesto[sizeof(score)];
char recordtesto[sizeof(record)];

void youLose(void){                  //Stampo a schermo la scritta "You lose" se il giocatore perde
	GUI_Text(90, 75, "YOU LOSE", Yellow, Black);
}

void scoreAndRecordPrint(void){      //Stampo a schermo il valore di score e il record
	sprintf(scoretesto, "%d", score);
	GUI_Text(10, 155, (uint8_t *)scoretesto, White, Black);
	sprintf(recordtesto, "%d", record);
	GUI_Text(200, 8, (uint8_t *)recordtesto, White, Black);
}


/*********************************************************************************************************
      END FILE
*********************************************************************************************************/

