/*********************************************************************************************************
      INIZIO PARTE DEFINITA PER PROGETTO
			AUTORE: Alex Carluccio
			UNIVERITA': Politecnico di Torino
			ANNO: 2021-2022
*********************************************************************************************************/
#include <stdio.h>
#include <math.h>
#include <stdbool.h> 
#include <stdlib.h>
#include "LPC17xx.H"                   
#include "../GLCD/GLCD.h"
#include "../game/gamefield.h"
#include "../game/ball.h"
#include "../game/gui.h"
#include "../timer/timer.h"

bool hasBounced=false;
int positionY[3]={160,159,159};
int positionX[3]={9,8,8};
int angleX=0;
int angleY=0;
int proj;
int step=1;
extern int score;
extern int record;
extern int boosterIncrement;

////////test//////////
int newballIncremX=1;
int newballIncremY=1;
////////test//////////



void bounceManagementPaddle(void){  //Gestisco il rimbalzo sul paddle
	angleX=positionX[0]-positionX[1];
	angleY=positionY[0]-positionY[1];
	
	if((positionX[0]-positionX[1])>0)
	  proj=(((positionY[0]-274)*(positionX[0]-positionX[1]))/(positionY[0]-positionY[1])); //Calcolo la proiezione all'altezza 274 per disegnare una palla coerente con la traiettoria ma che tocca il paddle senza entrarci dentro
	 	
	if((positionX[0]-positionX[1])<0)
		proj=(((positionY[0]-274)*((positionX[0]-positionX[1])*(-1)))/(positionY[0]-positionY[1])); 
	
	newballIncremY=angleY*(-1);
	newballIncremX=(angleX*(1))+boosterIncrement;
	setPosition((positionX[1]+proj),274);
	
	if(score<100){
		score=score+5;
	}else{
		score=score+10;
	}
}

void bounceManagementRight(void){ //Gestisco il rimbalzo sul muro di destra
	angleX=positionX[0]-positionX[1];
	angleY=positionY[0]-positionY[1];
	
	newballIncremX=angleX*(-1);
	newballIncremY=angleY*(1);
}

void bounceManagementTop(void){  //Gestisco il rimbalzo sul muro di sopra
	angleX=positionX[0]-positionX[1];
	angleY=positionY[0]-positionY[1];
	
	newballIncremX=angleX*(1);
	newballIncremY=angleY*(-1);
}

void bounceManagementLeft(void){ //Gestisco il rimbalzo sul muro di sinistra
	angleX=positionX[0]-positionX[1];
	angleY=positionY[0]-positionY[1];
	
	newballIncremX=angleX*(-1);
	newballIncremY=angleY*(1);
}


void checkBallOut(void) {       //Controllo se la palla � andata al di sotto del paddle
   if(positionY[0] > fieldYbassolimit()){
		 youLose();
		 if(score > record)
			 record=score;
		 
		 pauseGame();               //Se si verifica questo, metto in pausa il gioco
	 }
	 
}


void checkPosition(void) {

        
    if (positionY[0] <= (int)fieldYaltolimit()+4 ){     //Controllo se la palla sta rimbalzando sul muro di sopra
			bounceManagementTop();
    }
        
    if (positionX[0] <= (int)fieldXsinistralimit()+4 ){ //Controllo se la palla sta rimbalzando sul muro di sinistra
      bounceManagementLeft();
    }
    
    if (positionX[0] >= (int)fieldXdestralimit()-4 ){   //Controllo se la palla sta rimbalzando sul muro di destra
      bounceManagementRight();
    }

    if (positionY[0] >= ((int)paddleAltitude()-2)  &&   //Controllo se la palla sta rimbalzando sul paddle
        positionX[0] >= (int)paddlePosition()&&
        positionX[0] <= ((int)paddlePosition() + ((int)paddleLenght()))
        ){
			  bounceManagementPaddle();
    }

}
	
int ballXCurrentPosition(void){  //Funzione per avere la posizione corrente della palla sull'asse X
		return positionX[1];
}
	
int ballYCurrentPosition(void){ //Funzione per avere la posizione corrente della palla sull'asse Y
		return positionY[1];
}
	
	
void ballMovment(int incrementX, int incrementY){ //Funzione per stampare a schermo la palla
		
			
	   //Cancello la vecchia palla
	   LCD_DrawLine((positionX[2]-2),(positionY[2]-2),(positionX[2]+2),(positionY[2]-2),Black);
	   LCD_DrawLine((positionX[2]-2),(positionY[2]-1),(positionX[2]+2),(positionY[2]-1),Black);
	   LCD_DrawLine((positionX[2]-2),(positionY[2]),(positionX[2]+2),(positionY[2]),Black);
	   LCD_DrawLine((positionX[2]-2),(positionY[2]+1),(positionX[2]+2),(positionY[2]+1),Black);
	   LCD_DrawLine((positionX[2]-2),(positionY[2]+2),(positionX[2]+2),(positionY[2]+2),Black);
		
		
	   //Grafico la nuova palla
	   LCD_DrawLine((positionX[1]-2),(positionY[1]-2),(positionX[1]+2),(positionY[1]-2),Green);
	   LCD_DrawLine((positionX[1]-2),(positionY[1]-1),(positionX[1]+2),(positionY[1]-1),Green);
	   LCD_DrawLine((positionX[1]-2),(positionY[1]),(positionX[1]+2),(positionY[1]),Green);
	   LCD_DrawLine((positionX[1]-2),(positionY[1]+1),(positionX[1]+2),(positionY[1]+1),Green);
	   LCD_DrawLine((positionX[1]-2),(positionY[1]+2),(positionX[1]+2),(positionY[1]+2),Green);
		 
		 //Aggiorno la vecchia posizione 
		 positionX[2]=positionX[1];
		 positionY[2]=positionY[1];
		
		 //Aggiorno la presente posizione 
		 positionX[1]=positionX[0];
		 positionY[1]=positionY[0];
		
		 //Aggiorno la posizione futura della palla con gli incrementi
	   positionX[0] = positionX[0] + incrementX;
     positionY[0] = positionY[0] + incrementY;
   
}	
	
void setPosition(int x, int y) { //Funzione per settare la posizione corrente della palla
	
    positionX[1] = x;
    positionY[1] = y;
	
}
 
void resetGame(void){   //Funzione per resettare il gioco
	disable_timer(0);
	disable_timer(1);
	reset_timer(1);
	reset_timer(0);
	LCD_GameSetup();
  score=1;
  record=100;	
	boosterIncrement=0;
	step=0;
	
	//reset posizone
	positionY[0]=160;
	positionY[1]=159;
	positionY[2]=159;
  positionX[0]=9;
	positionX[1]=8;
	positionX[2]=8;
	newballIncremX=1;
  newballIncremY=1;
}

void startGame(void){   //Funzione per avviare il gioco
	score = 0;
	record=100;
	step=1;
	boosterIncrement=0;
	enable_timer(0);
	enable_timer(1);
	ballMovment(1,1);                            
}

void pauseGame(void){  //Funzione per mettere in pausa il gioco
	disable_timer(0);
	disable_timer(1);
}

void resumeGame(void){  //Funzione per rirpendere dalla pausa il gioco
	enable_timer(1);
	enable_timer(0);
}

void gameSpeed(void){  //Funzione per modificare la velocit� della palla durante il gioco man mano che si avanza di score
	if (score > 200 && step==1){
	 updateTimer(1);
	 step=2;
	}
	if (score > 400 && step==2){
	 updateTimer(2);
	 step=3;
	}
	if (score > 600 && step==3){
	 updateTimer(3);
	 step=4;
	}
	if (score > 800 && step==4){
	 updateTimer(4);
	 step=5;
	}
	if (score > 1000 && step==5){
	 updateTimer(5);
	 step=0;
	}
}

	
/*********************************************************************************************************
      END FILE
*********************************************************************************************************/





