#ifndef __BUZZER_H
#define __BUZZER_H

#include "lpc17xx.h"

/* USE TIMER3 */
	//disable_timer(3);
	//reset_timer(3);
	//init_timer(3, BUZZER_C3); 
	//enable_timer(3);
	

/* C3 to C5 */
#define BUZZER_C3 4240			/* Do:	131 Hz	*/
#define BUZZER_D3 3779			/* Re:	147 Hz	*/
#define BUZZER_E3 3367			/* Mi:	165 Hz	*/
#define BUZZER_F3 3175			/* Fa:	175 Hz	*/
#define BUZZER_G3 2834			/* Sol:	196 Hz	*/
#define BUZZER_A3 2525			/* La:	220 Hz	*/
#define BUZZER_B3 2249			/* Si:	247 Hz	*/
#define BUZZER_C4 2120			/* Do:	262 Hz	*/
#define BUZZER_D4 1890			/* Re:	294 Hz	*/
#define BUZZER_E4 1684			/* Mi:	330 Hz	*/
#define BUZZER_F4 1592			/* Fa:	349 Hz	*/
#define BUZZER_G4 1417			/* Sol:	392 Hz	*/
#define BUZZER_A4 1263			/* La:	440 Hz	*/
#define BUZZER_B4 1125			/* Si:	494 Hz	*/
#define BUZZER_C5 1062			/* Do:	523 Hz	*/
/* k=f/(f'*n) -> k=25MHz/(f'*45)						*/



#endif
