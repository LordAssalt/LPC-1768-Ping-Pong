/*----------------------------------------------------------------------------
 * Name:    sample.c
 * Note(s): this version supports the LANDTIGER Emulator
 * Author: 	Alex CARLUCCIO
 *----------------------------------------------------------------------------
 *
 * This software is supplied "AS IS" without warranties of any kind.
 *
 *----------------------------------------------------------------------------*/
                  
#include <stdio.h>
#include <stdbool.h> 
#include "LPC17xx.H"                    /* LPC17xx definitions                */
#include "led/led.h"
#include "button_EXINT/button.h"
#include "GLCD/GLCD.h" 
#include "game/gamefield.h" 
#include "game/ball.h" 
#include "RIT/RIT.h"
#include "adc/adc.h"
#include "timer/timer.h"
#include "buzzer/buzzer.h"

#ifdef SIMULATOR
extern uint8_t ScaleFlag; // <- ScaleFlag needs to visible in order for the emulator to find the symbol (can be placed also inside system_LPC17xx.h but since it is RO, it needs more work)
#endif

/*----------------------------------------------------------------------------
  Main Program
 *----------------------------------------------------------------------------*/
 
int main (void) {
  
  SystemInit();  												/* System Initialization (i.e., PLL)  */
	LCD_Initialization();                 /* Inizializza il display             */
	LCD_GameSetup();                      /* Setta sfondo e barre laterali      */
	BUTTON_init();												/* BUTTON Initialization              */
	init_RIT(0x001312D0);                 /* RIT Initialization 12.5 msec      	*/
	init_timer(1,0x0005B8D8);             /* Inizializzo il timer 1 a 00 ms     */
  init_timer(0,0x0005B8D8);             /* Inizializzo il timer 0 a 00 ms     */
	init_timer(3, 850);                   /* Inizializzo il timer 3 a 00 ms     */
	ADC_init();                           /* Inizializzo l'ADC converter        */
	enable_RIT();													/* RIT enabled												*/

	
	
	
	LPC_SC->PCON |= 0x1;								  /* Power down mode                    */
	LPC_SC->PCON &= ~(0x2);						
  while (1) {                           /* Loop wait for interrupt            */	
     __ASM("wfi");
	}

}
/*********************************************************************************************************
TO_DO:
-Check Finale
-Buzzer
*********************************************************************************************************/

